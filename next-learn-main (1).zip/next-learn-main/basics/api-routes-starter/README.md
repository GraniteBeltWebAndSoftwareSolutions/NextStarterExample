This is a starter template for [Learn Next.js](https://nextjs.org/learn).
